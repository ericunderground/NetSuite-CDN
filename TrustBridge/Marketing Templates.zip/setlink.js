//Change the URL below to edit the location that the logo on the form "clicks" to
const URL = "https://www.trustbridgeglobal.com/";


//...But don't touch this
function setHREF(){
  this.href=URL;
}
